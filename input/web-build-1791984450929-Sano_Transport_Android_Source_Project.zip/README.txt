SANO TRANSPORT ACCOUNTS — ANDROID SOURCE PROJECT

This is a starter Android project wrapping the offline accounting web app in a WebView.
Data is stored in WebView localStorage on this phone. No internet permission is declared.
Uninstalling the app or clearing its app data may erase records, so use the in-app backup feature.

Project structure:
- settings.gradle
- build.gradle
- app/build.gradle
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/sano/transportaccounts/MainActivity.java
- app/src/main/assets/index.html

This project ZIP is source code, NOT an APK. It must be built by an Android build service or Android Studio.
For a beginner, do not enter a GitHub password or personal access token into an unknown site.
